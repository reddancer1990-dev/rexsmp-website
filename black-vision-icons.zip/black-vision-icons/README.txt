Black Vision Dark Icon Pack
============================

21 minimalist dark icons for iPhone Shortcuts.

HOW TO SET A CUSTOM ICON
------------------------
1. Unzip this folder on your iPhone (Files app).
2. Open Shortcuts → + → Add Action → Open App → pick your app.
3. Tap shortcut name → icon → Choose Photo → select the matching PNG.
4. Share → Add to Home Screen.

Files: safari.png, cursor.png, chatgpt.png, whatsapp.png, etc.
